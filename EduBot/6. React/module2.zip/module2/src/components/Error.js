import React from 'react';

const Error = ({ message }) => {
  return <div style={{ color: 'red' }}>{message}</div>;
};

export default Error;
