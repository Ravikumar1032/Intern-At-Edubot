import React from 'react';

const WeatherDisplay = ({ weather, forecast }) => {
  return (
    <div>
      <h2>Current Weather in {weather.name}</h2>
      <p>{weather.weather[0].description}</p>
      <p>Temperature: {Math.round(weather.main.temp - 273.15)}°C</p>

      <h3>5-Day Forecast</h3>
      <ul>
        {forecast.slice(0, 5).map((day, index) => (
          <li key={index}>
            <p>{new Date(day.dt_txt).toLocaleDateString()}</p>
            <p>{day.weather[0].description}</p>
            <p>Temperature: {Math.round(day.main.temp - 273.15)}°C</p>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default WeatherDisplay;
