import React, { useState } from 'react';
import axios from 'axios';
import SearchBar from './components/SearchBar';
import WeatherDisplay from './components/WeatherDisplay';
import Loading from './components/Loading';
import Error from './components/Error';

const App = () => {
  const [weather, setWeather] = useState(null);
  const [forecast, setForecast] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const fetchWeather = async (city) => {
    setLoading(true);
    setError('');
    try {
      const weatherRes = await axios.get(`https://api.openweathermap.org/data/2.5/weather`, {
        params: {
          q: city,
          appid: 'afb8a96240229a3576784a5e51e69775'
        }
      });
      const forecastRes = await axios.get(`https://api.openweathermap.org/data/2.5/forecast`, {
        params: {
          q: city,
          appid: 'afb8a96240229a3576784a5e51e69775'
        }
      });
      setWeather(weatherRes.data);
      setForecast(forecastRes.data.list);
    } catch (err) {
      console.error('Error fetching weather data:', err.response || err.message || err);
      setError('Unable to fetch weather data. Please try again.');
    }
    setLoading(false);
  };

  return (
    <div className="App">
      <h1>Weather App</h1>
      <SearchBar fetchWeather={fetchWeather} />
      {loading && <Loading />}
      {error && <Error message={error} />}
      {weather && <WeatherDisplay weather={weather} forecast={forecast} />}
    </div>
  );
};

export default App;
