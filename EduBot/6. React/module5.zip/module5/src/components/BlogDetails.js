import React from 'react';
import { useParams } from 'react-router-dom';

const blogs = [
  { id: 1, title: 'First Blog', content: 'This is the first blog content' },
  { id: 2, title: 'Second Blog', content: 'This is the second blog content' },
  { id: 3, title: 'Third Blog', content: 'This is the third blog content' },
];

const BlogDetails = () => {
  const { id } = useParams();
  const blog = blogs.find(blog => blog.id === parseInt(id));

  if (!blog) {
    return <div>Blog not found</div>;
  }

  return (
    <div>
      <h1>{blog.title}</h1>
      <p>{blog.content}</p>
    </div>
  );
};

export default BlogDetails;
