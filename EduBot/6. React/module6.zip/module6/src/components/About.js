import React from 'react';
import { Container, Typography } from '@mui/material';
import styled from 'styled-components';

const AboutContainer = styled(Container)`
  margin-top: 50px;
  text-align: center;
`;

const About = () => {
  return (
    <AboutContainer>
      <Typography variant="h4">About Me</Typography>
      <Typography variant="body1">
        I am a passionate web developer with experience in creating dynamic and responsive websites using modern web technologies.
      </Typography>
    </AboutContainer>
  );
};

export default About;
