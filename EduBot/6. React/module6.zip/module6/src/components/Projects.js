import React from 'react';
import { Container, Typography, Grid, Card, CardContent, CardMedia } from '@mui/material';
import styled from 'styled-components';

const ProjectsContainer = styled(Container)`
  margin-top: 50px;
`;

const projects = [
  { id: 1, title: 'Project One', image: 'https://i.ytimg.com/vi/YRqQpcaXgBw/maxresdefault.jpg', description: 'This is a description of Project One.' },
  { id: 2, title: 'Project Two', image: 'https://i.ytimg.com/vi/YRqQpcaXgBw/maxresdefault.jpg', description: 'This is a description of Project Two.' },
  { id: 3, title: 'Project Three', image: 'https://i.ytimg.com/vi/YRqQpcaXgBw/maxresdefault.jpg', description: 'This is a description of Project Three.' },
];

const Projects = () => {
  return (
    <ProjectsContainer>
      <Typography variant="h4" gutterBottom>
        My Projects
      </Typography>
      <Grid container spacing={3}>
        {projects.map((project) => (
          <Grid item xs={12} sm={6} md={4} key={project.id}>
            <Card>
              <CardMedia
                component="img"
                alt={project.title}
                height="140"
                image={project.image}
              />
              <CardContent>
                <Typography gutterBottom variant="h5" component="div">
                  {project.title}
                </Typography>
                <Typography variant="body2" color="text.secondary">
                  {project.description}
                </Typography>
              </CardContent>
            </Card>
          </Grid>
        ))}
      </Grid>
    </ProjectsContainer>
  );
};

export default Projects;
