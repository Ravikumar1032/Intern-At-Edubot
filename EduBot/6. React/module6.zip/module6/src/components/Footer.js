import React from 'react';
import { Typography } from '@mui/material';
import styled from 'styled-components';

const FooterContainer = styled.footer`
  background-color: #333;
  color: white;
  text-align: center;
  padding: 20px 0;
`;

const Footer = () => {
  return (
    <FooterContainer>
      <Typography variant="body1">&copy; 2024 My Portfolio. All rights reserved.</Typography>
    </FooterContainer>
  );
};

export default Footer;
