import React from 'react';
import { Container, Typography, TextField, Button } from '@mui/material';
import styled from 'styled-components';

const ContactContainer = styled(Container)`
  margin-top: 50px;
  text-align: center;
`;

const Contact = () => {
  return (
    <ContactContainer>
      <Typography variant="h4" gutterBottom>Contact Me</Typography>
      <form noValidate autoComplete="off">
        <TextField label="Name" variant="outlined" fullWidth margin="normal" />
        <TextField label="Email" variant="outlined" fullWidth margin="normal" />
        <TextField label="Message" variant="outlined" fullWidth margin="normal" multiline rows={4} />
        <Button variant="contained" color="primary" style={{ marginTop: '20px' }}>Send</Button>
      </form>
    </ContactContainer>
  );
};

export default Contact;
