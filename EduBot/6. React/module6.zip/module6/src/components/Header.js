import React from 'react';
import { AppBar, Toolbar, Typography, Button } from '@mui/material';
import styled from 'styled-components';

const StyledAppBar = styled(AppBar)`
  background-color: #333;
`;

const Header = () => {
  return (
    <StyledAppBar position="static">
      <Toolbar>
        <Typography variant="h6" style={{ flexGrow: 1 }}>
          My Portfolio
        </Typography>
        <Button color="inherit">About</Button>
        <Button color="inherit">Projects</Button>
        <Button color="inherit">Contact</Button>
      </Toolbar>
    </StyledAppBar>
  );
};

export default Header;
