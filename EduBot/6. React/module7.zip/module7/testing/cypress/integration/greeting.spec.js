describe('Greeting Component', () => {
    it('displays the correct greeting message with name', () => {
      cy.visit('/');
      cy.contains('Hello, Cypress!');
    });
  
    it('displays the default greeting message when no name is provided', () => {
      cy.visit('/');
      cy.contains('Hello, Stranger!');
    });
  });
  