import React from 'react';
import { useDispatch } from 'react-redux';
import { deleteTask } from '../redux/actions/taskActions';

const Task = ({ task }) => {
  const dispatch = useDispatch();

  const handleDelete = () => {
    dispatch(deleteTask(task.id));
  };

  return (
    <div>
      <h3>{task.title}</h3>
      <p>{task.description}</p>
      <button onClick={handleDelete}>Delete</button>
      {/* Add Edit functionality here */}
    </div>
  );
};

export default Task;
