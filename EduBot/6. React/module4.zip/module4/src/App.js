import React, { useContext } from 'react';
import TaskList from './components/TaskList';
import TaskForm from './components/TaskForm';
import ThemeToggle from './components/ThemeToggle';
import { ThemeContext } from './contexts/ThemeContext';
import './App.css';

const App = () => {
  const { theme } = useContext(ThemeContext);

  return (
    <div className={`App ${theme}`}>
      <h1>Task Management App</h1>
      <ThemeToggle />
      <TaskForm />
      <TaskList />
    </div>
  );
};

export default App;
