public class Lab1Ex1b {
    public static void main(String[] args) {
        System.out.println("Hello World")
    }
}
