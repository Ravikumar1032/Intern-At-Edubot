public class Lab1Ex1a {
    public static void main(String[] args) {
        System.out.println("Hello World");
    }
}
