public class Lab1Ex1d {
    public static void main(String[] args) {
        System.out.println("Hello World");
    }
}
