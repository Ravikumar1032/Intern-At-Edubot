public class A5_EquationSolver {
    public static void main(String[] args) {
        double result1 = 21.0 / 3 + (3 * 9) * 9 + 5;
        double result2 = (17 - 7) * 6 + 2 + 56 - 8;
        double result3 = 10 + 8 * 90 / 9 - 4;

        System.out.println("Result of equation 1: " + result1);
        System.out.println("Result of equation 2: " + result2);
        System.out.println("Result of equation 3: " + result3);
    }
}