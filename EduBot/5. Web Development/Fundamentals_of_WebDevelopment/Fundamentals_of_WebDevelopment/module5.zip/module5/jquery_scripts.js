$(document).ready(function() {
    // Part 2: Basic Selectors and Manipulation
    if ($('body').attr('id') === 'index') {
        $('#intro').text('Welcome to the Index Page!');
    }

    // Class and ID Selectors
    if ($('body').attr('id') === 'about') {
        $('#hideInfoBtn').click(function() {
            $('.info').hide();
        });
    }

    // Part 3: jQuery Events
    // Mouse Events
    if ($('body').attr('id') === 'index') {
        $('#hoverBtn').hover(
            function() {
                $(this).text('Mouse Over!');
            },
            function() {
                $(this).text('Hover Over Me');
            }
        );
    }

    // Keyboard Events
    if ($('body').attr('id') === 'contact') {
        $('#focusInput').focus(function() {
            $(this).css('background-color', 'yellow');
        }).blur(function() {
            $(this).css('background-color', '');
        });
    }

    // Part 4: jQuery Effects
    // Hide and Show Elements
    if ($('body').attr('id') === 'about') {
        $('#hideInfoBtn').click(function() {
            $('p').eq(0).hide(2000);
        });
    }

    // Fade Effects
    if ($('body').attr('id') === 'index') {
        $('#fadeInBtn').click(function() {
            $('#fadeImage').fadeIn();
        });
        $('#fadeOutBtn').click(function() {
            $('#fadeImage').fadeOut();
        });
    }

    // Slide Effects
    if ($('body').attr('id') === 'contact') {
        $('#slideToggleBtn').click(function() {
            $('#toggleDiv').slideToggle();
        });
    }

    // Part 5: jQuery DOM Manipulation
    // Adding and Removing Elements
    if ($('body').attr('id') === 'about') {
        $('#addItemBtn').click(function() {
            $('#itemList').append('<li>New Item</li>');
        });
    }

    // Modifying Content and Attributes
    if ($('body').attr('id') === 'index') {
        $('#changeHrefBtn').click(function() {
            $('#dynamicLink').attr('href', 'https://newurl.com');
        });
    }

    // Prepending and Appending Elements
    if ($('body').attr('id') === 'contact') {
        $('#prependBtn').click(function() {
            $('#modifyText').prepend('Prepended Text - ');
        });
        $('#appendBtn').click(function() {
            $('#modifyText').append(' - Appended Text');
        });
    }

    // Part 6: Advanced jQuery Traversal
    // Traversing the DOM
    if ($('body').attr('id') === 'about') {
        $('div#specificDiv p').css('color', 'blue');
    }

    // Finding and Filtering Elements
    if ($('body').attr('id') === 'index') {
        $('table tr:even').css('background-color', '#f2f2f2');
    }
});
