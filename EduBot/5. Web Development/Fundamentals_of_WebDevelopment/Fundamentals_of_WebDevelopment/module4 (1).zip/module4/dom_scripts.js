// Check if the current page matches the specified id
function isPage(pageId) {
    return document.body.getAttribute('id') === pageId;
}

// Manipulate text content
if (isPage('index')) {
    document.getElementById('intro').textContent = 'Welcome to the Index Page!';
}

// Button click event to change text color
if (isPage('index')) {
    document.getElementById('changeTextColorBtn').addEventListener('click', () => {
        document.getElementById('textParagraph').style.color = 'red';
    });
}

// Change image source
if (isPage('about')) {
    document.getElementById('changeImageBtn').addEventListener('click', () => {
        document.getElementById('profilePic').src = 'new_image.jpg';
    });
}

// Add new list item
if (isPage('contact')) {
    document.getElementById('addListItemBtn').addEventListener('click', () => {
        const newItem = document.createElement('li');
        newItem.textContent = 'New Contact Item';
        document.getElementById('contactList').appendChild(newItem);
    });
}

// Remove last list item
if (isPage('contact')) {
    document.getElementById('removeListItemBtn').addEventListener('click', () => {
        const contactList = document.getElementById('contactList');
        contactList.removeChild(contactList.lastChild);
    });
}

// Replace paragraph
if (isPage('index')) {
    document.getElementById('replaceParagraphBtn').addEventListener('click', () => {
        const newParagraph = document.createElement('p');
        newParagraph.textContent = 'This is the new paragraph content.';
        const oldParagraph = document.getElementById('textParagraph');
        oldParagraph.parentNode.replaceChild(newParagraph, oldParagraph);
    });
}

// Change text color of all list items
if (isPage('about')) {
    document.getElementById('changeListItemsColorBtn').addEventListener('click', () => {
        const listItems = document.querySelectorAll('#hobbiesList li');
        listItems.forEach(item => {
            item.style.color = 'blue';
        });
    });
}

// Add CSS class dynamically
if (isPage('contact')) {
    document.getElementById('addClassBtn').addEventListener('click', () => {
        const dynamicDiv = document.getElementById('dynamicDiv');
        dynamicDiv.classList.add('new-style');
    });
}

// Create a new div containing an image and a paragraph
if (isPage('index')) {
    document.getElementById('createDivBtn').addEventListener('click', () => {
        const newDiv = document.createElement('div');
        const newImg = document.createElement('img');
        newImg.src = 'new_image.jpg';
        const newParagraph = document.createElement('p');
        newParagraph.textContent = 'This is a new paragraph inside the new div.';
        newDiv.appendChild(newImg);
        newDiv.appendChild(newParagraph);
        document.body.appendChild(newDiv);
    });
}
