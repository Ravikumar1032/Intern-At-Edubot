document.addEventListener("DOMContentLoaded", function() {
    const canvas = document.getElementById('myCanvas');
    const ctx = canvas.getContext('2d');

    // Check which page is loaded
    const pageId = document.body.id;

    // Part 2: Drawing Shapes and Lines
    if (pageId === 'index' || pageId === 'about' || pageId === 'contact') {
        // Draw filled rectangle
        ctx.fillStyle = 'blue';
        ctx.fillRect(50, 50, 150, 100);

        // Draw stroked rectangle
        ctx.strokeStyle = 'red';
        ctx.strokeRect(250, 50, 150, 100);

        // Draw filled circle
        ctx.beginPath();
        ctx.arc(150, 300, 75, 0, Math.PI * 2);
        ctx.fillStyle = 'green';
        ctx.fill();
        ctx.closePath();

        // Draw stroked circle
        ctx.beginPath();
        ctx.arc(350, 300, 75, 0, Math.PI * 2);
        ctx.strokeStyle = 'purple';
        ctx.stroke();
        ctx.closePath();

        // Draw lines
        ctx.beginPath();
        ctx.moveTo(50, 450);
        ctx.lineTo(250, 450);
        ctx.lineTo(150, 550);
        ctx.closePath();
        ctx.strokeStyle = 'orange';
        ctx.stroke();
    }

    // Part 3: Text and Styles
    if (pageId === 'index') {
        // Draw text
        ctx.font = '30px Arial';
        ctx.fillStyle = 'black';
        ctx.fillText('Hello Canvas', 50, 50);
        ctx.strokeText('Hello Canvas', 50, 100);

        // Apply gradient
        const gradient = ctx.createLinearGradient(0, 0, canvas.width, 0);
        gradient.addColorStop(0, 'blue');
        gradient.addColorStop(1, 'red');
        ctx.fillStyle = gradient;
        ctx.fillRect(50, 150, 200, 100);
    }

    // Part 4: Images and Patterns
    if (pageId === 'about') {
        const img = new Image();
        img.src = 'https://via.placeholder.com/150';
        img.onload = function() {
            ctx.drawImage(img, 400, 50, 150, 150);

            // Create pattern
            const pattern = ctx.createPattern(img, 'repeat');
            ctx.fillStyle = pattern;
            ctx.fillRect(50, 250, 200, 200);
        };
    }

    // Part 5: Animations
    if (pageId === 'contact') {
        let x = 50;
        let y = 50;
        let dx = 2;
        let dy = 2;

        function animate() {
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            ctx.beginPath();
            ctx.arc(x, y, 30, 0, Math.PI * 2);
            ctx.fillStyle = 'blue';
            ctx.fill();
            ctx.closePath();

            x += dx;
            y += dy;

            if (x + 30 > canvas.width || x - 30 < 0) dx = -dx;
            if (y + 30 > canvas.height || y - 30 < 0) dy = -dy;

            requestAnimationFrame(animate);
        }

        animate();

        // User Interaction
        canvas.addEventListener('click', function(event) {
            const rect = canvas.getBoundingClientRect();
            const mouseX = event.clientX - rect.left;
            const mouseY = event.clientY - rect.top;

            ctx.beginPath();
            ctx.arc(mouseX, mouseY, 20, 0, Math.PI * 2);
            ctx.fillStyle = 'red';
            ctx.fill();
            ctx.closePath();
        });
    }

    // Part 6: Advanced Drawing Techniques
    if (pageId === 'index') {
        // Complex paths using bezierCurveTo and quadraticCurveTo
        ctx.beginPath();
        ctx.moveTo(300, 300);
        ctx.bezierCurveTo(400, 200, 500, 400, 600, 300);
        ctx.strokeStyle = 'blue';
        ctx.stroke();

        ctx.beginPath();
        ctx.moveTo(300, 400);
        ctx.quadraticCurveTo(400, 300, 500, 400);
        ctx.strokeStyle = 'green';
        ctx.stroke();

        // Clipping and transformations
        ctx.save();
        ctx.translate(50, 450);
        ctx.rotate((Math.PI / 180) * 25);
        ctx.fillStyle = 'red';
        ctx.fillRect(0, 0, 100, 50);
        ctx.restore();

        ctx.beginPath();
        ctx.rect(650, 50, 100, 100);
        ctx.clip();
        ctx.fillStyle = 'blue';
        ctx.fillRect(600, 0, 200, 200);
    }
});
