function displayData(data) {
    const pageId = document.body.id;
    const pageData = data.pages.find(page => page.id === pageId);

    if (pageData) {
        document.getElementById('page-title').textContent = pageData.title;
        document.getElementById('page-content').textContent = pageData.content;

        if (pageData.details) {
            const details = document.createElement('p');
            details.textContent = `Author: ${pageData.details.author}, Date: ${pageData.details.date}`;
            document.body.appendChild(details);
        }
    }
}
