const data = {
    name: "John Doe",
    age: 25,
    password: "secret"
};

const jsonData = JSON.stringify(data, (key, value) => {
    if (key === 'password') {
        return undefined; // Exclude password
    }
    return value;
});

console.log(jsonData); // Output: {"name":"John Doe","age":25}
