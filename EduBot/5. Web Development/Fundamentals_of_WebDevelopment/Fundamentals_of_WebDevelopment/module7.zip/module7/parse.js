function fetchData(callback) {
    const xhr = new XMLHttpRequest();
    xhr.open('GET', 'data.json', true);
    xhr.onreadystatechange = function() {
        if (xhr.readyState === 4 && xhr.status === 200) {
            const data = JSON.parse(xhr.responseText, (key, value) => {
                if (key === 'content') {
                    return value.toUpperCase(); // Example modification
                }
                return value;
            });
            callback(data);
        }
    };
    xhr.send();
}
