// Fetch data using Fetch API
function fetchData(callback) {
    fetch('data.json')
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok ' + response.statusText);
            }
            return response.json();
        })
        .then(data => {
            callback(data);
        })
        .catch(error => {
            console.error('There was a problem with the fetch operation:', error);
        });
}

// Display data on the webpage
function displayData(data) {
    const pageId = document.body.id;
    const pageData = data.pages.find(page => page.id === pageId);

    if (pageData) {
        document.getElementById('page-title').textContent = pageData.title;
        document.getElementById('page-content').textContent = pageData.content;

        if (pageData.details) {
            const details = document.createElement('p');
            details.textContent = `Author: ${pageData.details.author}, Date: ${pageData.details.date}`;
            document.body.appendChild(details);
        }
    }
}

// Call fetch function on page load
document.addEventListener('DOMContentLoaded', function() {
    fetchData(displayData);
});
